package com.springboot_hybernet_relationship_deign_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHibernateRelationshipDesign1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
