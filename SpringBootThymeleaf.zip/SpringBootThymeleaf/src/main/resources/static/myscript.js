/**
 * 
 */

'use strict';

alert("Welcome User");